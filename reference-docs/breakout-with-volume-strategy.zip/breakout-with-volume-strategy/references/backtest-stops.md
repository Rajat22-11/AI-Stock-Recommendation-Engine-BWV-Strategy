# Backtest — which stop, and which breakouts (run 1 Oct 2026)

Trigger for this study: two day-one stop-outs on a pivot − 1% stop (JSWINFRA 28 Sep, SEDEMAC 1 Oct 2026 — SEDEMAC hit ₹3,333 intraday and closed back near ₹3,430).

## Data and method
- **Data:** `github.com/BennyThadikaran/eod2_data` — NSE end-of-day CSVs for ~3,740 listed stocks, split/bonus adjusted, updated weekly. **Survivorship bias:** only currently-listed symbols, so stocks that collapsed and delisted are missing; this flatters wide stops and no-stop rules.
- **Universe/filters:** EQ symbols (SME excluded), price ≥ ₹30, median 20-day turnover ≥ ₹1 cr.
- **Signal (weekly, Friday close):** close > prior-52-week high (pivot), prior week not already above its pivot, per-session-normalized volume ≥ 2x the 20-week median, close > 13w SMA. Signals 2012-01 → 2026-09: **10,866 trades** after dropping 11 trades caused by bad adjustment data.
- **Entry:** next session open; skipped if that open is below pivot × 0.99 (failed before entry).
- **Common exit for all stop rules:** weekly close below the 13w SMA (exit next open) or a 52-week time stop. A second, cleaner measure holds 13 weeks with only the stop.
- **Fills:** stop fills at the stop, or at the open on a gap through it; entry-day intraday hits count (conservative). Costs 0.25% round trip.
- **Capital metric:** position = min(1% ÷ stop risk, 10%) of capital, as in the skill; "cap bp" = return on total capital per trade in basis points. This is the number that matters with a 10% position cap, because the cap binds for any stop tighter than 10%.
- Scripts: `scripts/extract_breakouts.py`, `scripts/simulate_stops.py`, `scripts/test_screens.py` (run from a folder containing `eod2_data/` and an empty `bt_out/arr/`).

## Stop rules on identical trades

| Rule | Avg risk | Stopped | Stops that later ran +15% | Win % | Avg R | Cap bp | Cap bp (13w hold) |
|---|---|---|---|---|---|---|---|
| Fixed 5% | 5.0% | 79% | — | 19.3 | 0.48 | 23.8 | 12.6 |
| **Pivot − 1%, cap 8% (old rule)** | 5.4% | 77% | 37% | 20.0 | 0.48 | 26.0 | 14.6 |
| Fixed 6% | 6.0% | 74% | — | 22.6 | 0.45 | 26.9 | 15.1 |
| Daily close < pivot (+8% hard) | 8.0% | 75% | 35% | 22.6 | 0.37 | 29.3 | 17.3 |
| Daily close < pivot + hard pivot − 1 ATR | 7.2% | 75% | 35% | 22.4 | 0.41 | 28.9 | 16.9 |
| Pivot − 1 ATR, cap 8% | 7.2% | 69% | 33% | 26.1 | 0.50 | 33.5 | 20.2 |
| Weekly close < pivot (+8% hard) | 8.0% | 71% | 33% | 25.8 | 0.43 | 34.0 | 21.0 |
| Entry − 2 ATR, cap 8% | 7.4% | 68% | 32% | 27.1 | 0.49 | 34.4 | 21.6 |
| Pivot − 1.5 ATR, cap 8% | 7.7% | 66% | 32% | 28.0 | 0.49 | 36.4 | 23.1 |
| Breakout-week low, cap 8% | 7.7% | 66% | 32% | 27.9 | 0.49 | 36.5 | 23.0 |
| **Fixed 8% below fill (new rule)** | 8.0% | 64% | 32% | 29.0 | 0.47 | **37.4** | **23.9** |
| Fixed 10% | 10% | 54% | — | 33.7 | 0.45 | 44.8 | 29.9 |
| Fixed 12% | 12% | 44% | — | 37.2 | 0.44 | 44.2 | 30.4 |
| No price stop (13w SMA exit only) | — | 0% | — | 43.4 | — | 71.4 | 64.1 |

Paired differences vs the old rule (same trades): fixed 8% +11.3 bp (t = 8.3); pivot − 1.5 ATR +10.4 bp (t = 7.7); week low +10.4 bp (t = 7.8). Fixed 8% vs pivot − 1.5 ATR: +1.0 bp (t = 3.5) — statistically detectable, economically a tie.

### Conclusions
1. **The pivot − 1% stop is the problem.** Worst rule except fixed 5%. When the fill is within 3% of the pivot (the normal case), it stopped 87% of trades and returned 13 bp vs 38 bp for fixed 8%.
2. **Fixed 8% ≈ pivot − 1.5 ATR ≈ breakout-week low** — all three converge because the 8% cap binds on most trades. Fixed 8% is the simplest and marginally best: adopted.
3. **ATR is not useful for stop placement here, but it is a strong volatility filter** (table below).
4. **Close-based stops are worse**, not better — the daily-close rule was the second-worst family.
5. **Wider than 8% scored higher**, and no stop scored highest. Not adopted: survivorship bias specifically flatters this, no-stop has a −21.5% 5th-percentile trade and −84% worst, and 8% is Deodhar's stated ceiling. Revisit only with a bias-free dataset.
6. Ranking held in every split tested: 2012–15, 2016–19, 2020–22, 2023–26; weak vs strong breadth; ATR buckets; deep vs shallow bases.

## Selection evidence (fixed 8% stop, cap bp per trade)

| Factor | Buckets → cap bp |
|---|---|
| Daily ATR % at signal | ≤3%: 56 · 3–4%: 52 · 4–5%: 35 · 5–7%: 21 · >7%: −14 |
| Breakout volume ÷ 20w median | 2–3x: 50 · 3–5x: 39 · 5–10x: 30 · >10x: 22 |
| Close vs 13w SMA at signal | ≤10%: 54 · 10–20%: 37 · 20–30%: 31 · >30%: 42 |
| Prior correction depth | <20%: 39 · 20–35%: 20 · 35–50%: 45 · >50%: 47 |
| Entry vs pivot | <2%: 39 · 2–5%: 32 · 5–8%: 46 · >8%: 36 |
| Market breadth (% NSE stocks above 200 DMA) | <50%: 47 · ≥50%: 35 |

Univariate, overlapping, one universe — treat as direction, not precise weights. Weekly ATR(14) ≈ 2.27 × daily ATR(14) across NSE (IQR 2.07–2.54), so daily ATR 5% ≈ weekly 11%.

## Baseline honesty
Average trade with the new stop: +3.7%, win rate 29%, profit factor 1.67, 64% stopped out. This is a low-hit-rate, fat-right-tail system: most trades lose ~8%, a few return 30%+. Losing streaks of 5–10 trades are normal and not evidence the rule is broken.

## Case: SEDEMAC, 1 Oct 2026
Fill ₹3,449.35, pivot ₹3,368.9, daily ATR ~₹169 (4.9%). Old stop ₹3,335 (−3.3%, 0.67 ATR) — hit at ~₹3,333 intraday, stock recovered to ~₹3,430 the same afternoon. New rule: ₹3,173 (−8%). Pivot − 1.5 ATR = ₹3,115 → capped to the same ₹3,173.
