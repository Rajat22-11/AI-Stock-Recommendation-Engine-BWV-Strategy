# Case log — post-mortems of past calls

Each case: what the framework said at each completed weekly close, what happened after, and what (if anything) changed in the skill. One case never proves a rule; look for repeats across cases.

---

## RAYMOND — reviewed 16 Sep 2026

**Context.** Post-demerger (Lifestyle 2024, Realty May 2025) pure-play engineering: aerospace & defence (JK Maini) + precision tech/auto. Q1 FY27 (8 Aug 2026): total income +13% to ₹628 cr, EBITDA +14% to ₹100 cr, PAT +50% to ₹31 cr, A&D revenue +40%, net cash. 52-week low ₹320 (30 Mar 2026).

**Weekly replay (13w SMA, prior-52w high, vol ÷ 20w avg):**

| Week of | Close | Prior 52w high | 13w SMA | Dist. | Vol x | Framework verdict |
|---|---|---|---|---|---|---|
| 24 Aug | 626.9 | 659.0 | 600.2 | +4.4% | 0.49x | WAIT — no trigger |
| 31 Aug | 740.9 | 659.0 | 618.0 | +19.9% | 5.57x | ENTRY (stretched band), why grade B (Q1 numbers + A&D re-rating) |
| 7 Sep | 1002.8 | 765.0 | 650.4 | +54.2% | 8.78x | New entry: WAIT (extended). Holders from 740.9: TRIM (+35%) + climax flag |
| 14 Sep (partial, 1 session) | 996.0 | 1024.5 | ~681.9 | +46% | n/a (partial) | Holders: trim already due; ASM placed 15 Sep; day high 1122 → close 996 on record 22.7M volume |

**Catalysts in the move.** Board fund-raise meeting 8 Sep → ₹214.7 cr preferential warrants to Minerva Ventures Fund at ₹645 (grade C catalyst, conversion price ~35% below current price). Short-term ASM placement 15 Sep.

**Sizing illustration (₹1,00,000 capital).** At ₹740.9 entry, stop ₹618 → risk ₹123/share → 8 shares (5.9% of capital). At ₹1002.8 entry, stop ₹650 → risk ₹352/share → 2 shares (2.0%). The 1% rule already punishes chasing; the extension check makes it explicit.

**Outcome so far.** Clean week-of-31-Aug entry → +34% in ~2 weeks; trim band hit by 11 Sep. Stage 4 would not fire until a weekly close meaningfully below ~₹682 (≈ −31% from ₹996), so without trimming most of the gain is exposed. Final outcome still OPEN — update this entry later.

**Skill changes made from this case.**
1. Partial-week handling (the 14 Sep bar was one session; 3.40x "weekly" volume was misleading).
2. Mandatory extension check → `WAIT (extended)`.
3. Why-quality grading (warrant issue ≠ earnings driver).
4. Climax flag in Stage 2 + explicit note of Stage 4 lag.
5. Corporate-action / raw_close check (demerger-adjusted history).
6. Missing calibration reference file created.

**Update 22 Sep 2026 — Rajat did NOT take the trade (missed).**

| Week of | Close | High | 13w SMA | Dist. | Vol x | Read |
|---|---|---|---|---|---|---|
| 14 Sep (4 sessions) | 978.0 | 1122.0 | 680.6 | +43.7% | 6.15x | Down week (−2.5%) on heavy volume = distribution-type week, but far above SMA → holders HOLD; new buyers WAIT (extended) |
| 21 Sep (partial, 1 session) | 1084.95 | 1120.0 | ~718.5 | +51% | n/a | Rebound toward 1122 high; aerospace order news + textile-sector (RoSCTL) sympathy buying |

- Missed-trade cost: signal close ₹740.85 → ₹1,084.95 = **+46%** in ~2.5 weeks.
- ASM did not end the leg; the stock based ₹937–1,122 for a week and bounced. The climax flag was a caution, not a top call.
- The extension filter cost little: a ₹1,002.8 entry is +8% but went −6.5% intra-week, all at a tiny size.
- Week of 24 Aug (close 626.85, 4.9% below the 52w high of 659, SMA rising) would have been a `WAIT (alert)` → the move was catchable with a price alert.

**Skill changes from this update:** `WAIT (alert)` near-trigger state; mandatory next-session action plan with max chase price; defined re-entry paths after an extended move (pullback to SMA, or a new ≥3-week base then breakout).

**Still open:** does a new base form above ~₹937 (re-entry via path b) or does it pull back toward the SMA (path a)? Log it.

---

## ACMESOLAR — first checked 16 Sep 2026

Weekly close 402.3 (w/o 7 Sep), 52w high 430.5, rising 13w SMA ~385, +6–9% above SMA. Failed breakout w/o 31 Aug (418 close on 1.29x). Verdict `WAIT (alert)`: alert ₹430.5, needs ≥2.5x weekly volume. Flags: D/E 3.93, promoter holding −11.9% last quarter (cause unverified). If triggered → `ENTRY (reduced)`. Log outcome.


**Update 22 Sep 2026 — TRIGGERED.** Week of 14 Sep (4 sessions) closed 435.25 > 430.5 on 19.8M shares = 2.59x the per-session-normalized 20w median (only 1.89x raw total vs mean — would have been misread without normalization + median). Mon 21 Sep follow-through +5.2% to 458.1 on ~3.3x. Verdict `ENTRY (reduced)` (why grade B, D/E 3.93, promoter selldown). Signal close 435.25, max chase 457.0, stop = 13w SMA 386.5. Log outcome.

---

## Batch check — 22 Sep 2026 (all OPEN)

| Stock | Last completed wk close | 52w high | Dist. SMA | Vol (median) | 8wk base | Verdict |
|---|---|---|---|---|---|---|
| AEGISLOG | 1415.4 | 1497.8 | +7.8% | 0.98x | 18.4%, volume dried to 0.2–0.5x | WAIT (alert) ₹1,497.8, needs ≥~15M/wk; partial wk poking above on 1.5x |
| WELCORP | 2660.1 | 2784.8 | +34.8% | 3.42x (down week, wide 2240–2718) | n/a (trending) | WAIT (extended); other-income flag |
| LAURUSLABS | 1954.0 | 1982.0 | +12.3% | 1.15x | 10.9% | WAIT (alert) ₹1,982; partial-wk close above on 1.1x = no-volume breakout |
| NYKAA | 332.15 | 349.55 | +1.3% | 0.76x | 5.6% (tightest), volume drying | WAIT (alert) ₹349.55, needs ≥~70M/wk; PE ~379 |

**Skill changes from this batch:** median (not mean) volume baseline; per-session normalization for holiday weeks; base-quality ranking for alerts; earnings-quality (other income) downgrade in why-grading.


---

## FINCABLES — checked 22 Sep 2026 (OPEN)

| Week of | Close | Prior 52w high | 13w SMA | Dist. | Vol x (median) | Read |
|---|---|---|---|---|---|---|
| 10 Aug | 1246.85 | 1203.9 | 1074.7 | +16.0% | 17.1x | ENTRY (Q1 FY27 beat: rev +44%, EBITDA +79%) |
| 31 Aug | 1220.2 | 1374.0 | 1117.3 | +9.2% | 2.33x | Down week, closed at 30% of range → real distribution week (1) |
| 7 Sep | 1424.0 | 1374.0 | 1147.2 | +24.1% | 4.47x | 2nd ENTRY (stretched band) |
| 14 Sep (4 sess.) | 1411.2 | 1498.0 | 1166.2 | +21.0% | 2.37x | Down week but closed at 83% of range → absorption, not distribution |
| 21 Sep (partial) | live ~1459 | 1498.0 | ~1188 | ~+23% | ~2.3x/session | Pressing 1498 |

Verdict `WAIT (alert)`: the 7 Sep signal's action window (week of 14 Sep) has passed. Alert: weekly close > ₹1,498 on ≥ ~6.4M shares (2.5x the 2.56M median). Flags: other income ₹382 cr of ₹714 cr TTM PAT; OCF −76% YoY (red flag #7) → if triggered, `ENTRY (reduced)`. D/E 0, PE ~28.
**Skill changes:** a signal's action window is one week, then it expires to WAIT (alert); close-location filter for distribution weeks.


---

## Framework correction — 25 Sep 2026 (source articles supplied)

Rajat supplied Deodhar's four full articles. Three things in the skill were **wrong**, not merely uncalibrated, and were rewritten:

1. **Initial stop.** The skill used the 13-week SMA as the initial stop, producing absurd risk (ACMESOLAR 15.6%, FINCABLES ~20%, ENGINERSIN ~19%) and artificially tiny positions. Deodhar's actual rule: **stop just below the breakout pivot, capped at 8% below the fill, whichever is closer.** Re-worked: ACMESOLAR at ₹458.1 fill, pivot ₹430.5 → stop ₹426 (−7.0%), risk ₹32/share not ₹72 — roughly double the correct position size. The SMA is a trend/trim reference only.
2. **Entry conditions.** Only 2 of 4 were being checked (breakout + volume). The missing two: a **deep prior correction** (40–60% typical) and a **first higher low**. Both added as mandatory.
3. **Add rule and exit trigger.** Adds are **not** "pullback to the SMA that holds" — they are a **high-tight-flag breakout on rising volume, never inside the flag**. And the final exit is the **break of the most recent higher low on heavy volume**, not an SMA break; it comes last in a 4-signal sequence (euphoria → failure bar → distribution chop → capitulation), each stage selling more.

Also removed: the invented `WAIT (extended)` entry gate. Its justification was that an SMA stop made extended entries unsizeable — which was an artifact of the wrong stop rule. Overextension now lives where Deodhar puts it: as a **trim** trigger, measured against each stock's own history. Retained as compatible with the source: `WAIT (alert)`, the one-week action window, median volume baseline, per-session normalization, close-location filter, why-grading, base quality.

Open positions to re-check under the corrected rules: ACMESOLAR (stop ₹426, not ₹386), FINCABLES, JSWINFRA, AEGISLOG, LAURUSLABS, NYKAA, RADICO, ENGINERSIN.


---

## Calibration against Deodhar's own watchlist — 26 Sep 2026

His weekend list: Cupid, Vidhi Specialty Food Ingredients, Nykaa, Eternal. How the previous skill would have handled them:

| Stock | His read | Old skill | Gap |
|---|---|---|---|
| Cupid | 15% pullback to rising 13w SMA, bounced, RS 89, triple-digit EPS growth | Fails condition 1 (no deep correction) → rejected as a new entry | Missing **Setup B** (continuation) |
| Vidhi | 50%+ correction, first higher low in July, RS 79, accelerating EPS | `WAIT (alert)` | Match; RS not checked |
| Nykaa | High tight flag at 13w SMA, inside bar, but RS 64 weak | `WAIT (alert)`, ranked best base | Match on setup; missed the weak RS |
| Eternal | Cup and handle, tight range above rising SMA, RS 81 | Likely rejected on condition 1 | Missing Setup B |

**Changes:** added Setup B (continuation/flag entry for new positions); selection signals (RS, SMA stack, accelerating EPS/revenue); a three-tier rule — soft on watchlist, strict on trigger, fixed on risk; watchlist mode.


---

## JSWINFRA + SEDEMAC whipsaws → stop rule replaced — 1 Oct 2026

| Trade | Fill | Pivot | Stop used | Daily ATR | Outcome |
|---|---|---|---|---|---|
| JSWINFRA | ₹360.45 (28 Sep) | ₹356.95 | ₹353 (−2.1%) | — | Stopped same day ~₹352.7, −₹218 |
| SEDEMAC | ₹3,449.35 (1 Oct) | ₹3,368.9 | ₹3,335 (−3.3%) | ~₹169 (4.9%) | Stopped ~₹3,333 intraday; recovered to ~₹3,430 by 15:10; Rajat re-bought (avg ₹3,441.53) |

Both stops sat inside one day's normal range. A full-NSE backtest (`backtest-stops.md`) confirmed it: pivot − 1% was the worst rule tested; fixed 8% below the fill was best within Deodhar's ceiling; ATR stops tied with it; close-based stops were worse; weak market breadth did *not* hurt breakouts (so no regime gate was added, despite the earlier JSWINFRA read).

**Skill changes:** stop = fill × 0.92; position = 10% of capital (the cap binds before 1% risk at an 8% stop); daily-ATR volatility filter (half size at 5–7%, NO-GO above 7%); volume sweet spot 2–3x with >10x flagged weaker; tested screen queries in `screen-intake.md`; `eod2_data` as a zero-API-cost source for completed weekly bars.

**SEDEMAC position now:** 2 sh @ ₹3,441.53 → stop ₹3,166 (−8%). OPEN — log the outcome.
