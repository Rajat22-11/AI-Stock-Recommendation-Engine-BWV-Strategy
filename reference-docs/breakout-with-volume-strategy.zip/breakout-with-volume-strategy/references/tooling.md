# Tooling — how to run each stage

Plain markdown output only. Never an HTML/JS artifact.

## API budget
Tapetide free tier = **50 MCP calls/day** (hit on 1 Oct 2026 mid-research). Spend calls on what only Tapetide has: screens, live quotes, the live partial week, fundamentals. Completed weekly bars come free from `eod2_data`.

## Standard data pull (every stage)
1. **Completed weeks — `eod2_data` (0 API calls).** Whole NSE, split/bonus-adjusted daily CSVs, updated weekly (lags to the last weekend):
   ```bash
   cd /tmp && [ -d eod2_data ] || git clone --depth 1 --filter=blob:none --sparse https://github.com/BennyThadikaran/eod2_data.git
   cd eod2_data && git sparse-checkout set daily     # ~450 MB, ~1 min; or: git sparse-checkout set daily/sedemac.csv
   ```
   File = `daily/<symbol lowercase>.csv` (Date, Open, High, Low, Close, Volume, …). Resample to `W-FRI`, count sessions per week for normalization, and **check the last date** — anything after it must come from Tapetide. It also gives a true RS percentile (rank the weighted return against every NSE stock) instead of the approximation below. Under the bash egress allow-list GitHub is reachable; the GitHub REST API rate-limits quickly, so use `git clone`, not the API.
2. Fallback / live week: `get_price_history(symbol, interval="weekly", days=450)` — 1 call per stock.
3. `get_price_history(symbol, days=10)` — daily bars, to count sessions in the current week and see the breakout day (also gives daily ATR for Step 4b).
4. `get_batch_quotes([...])` (≤20 symbols, 1 call) — live price for entry zone, gain% and stop distance. Quotes are intraday; never treat one as a weekly close.

Compute in code, not by eye: SMA13 = mean of the last 13 weekly closes (also report its slope over 4 weeks); volume multiple = week ÷ median of prior 20 weeks, per-session normalized; distance = close ÷ SMA13 − 1; close location = (close − low) ÷ (high − low).

## Relative Strength (approximation)
Deodhar quotes an RS rating (a 1–99 percentile of the stock's performance vs the market). Tapetide has no RS field, so approximate it and label it as approximate:
- Weighted return = 0.4 × 3-month + 0.2 × 6-month + 0.2 × 9-month + 0.2 × 12-month return, from weekly closes.
- Compare against the same weighted return for NIFTY 500 (`get_index_history`), and against the scan universe from `screen_stocks_technical` (columns `Perf.3M`, `Perf.6M`, `Perf.Y`) to estimate a percentile.
- If Rajat reads RS off his own charting tool, use his number over the approximation.

## SMA stack
Compute the 13, 26, 39 and 52-week SMAs from weekly closes and report whether they're stacked (13 > 26 > 39 > 52) and whether each is rising.

## The fundamental "why"
- `get_company_profile` — D/E, ROE/ROCE, PE, cash-flow and other-income flags, latest quarterly growth.
- `get_financials` (quarterly) — EPS and revenue YoY for the last 4 quarters, to test whether growth is **accelerating**.
- `get_stock_events(type="news")`, `type="corporate_actions"`, `type="filings")` — the trigger event.
- `get_earnings_call_summary`, `get_forecasts` — management guidance and estimates.
- `get_shareholding`, `get_promoter_pledge` — promoter selldown or pledge stress.
- `web_search` — last 2 weeks of news; also the only reliable source for ASM/GSM placement.
- Deeper fundamental verdict → hand to the `fundamental-analysis` / `finology-fundamental-analysis` skill and relay FinStar; don't duplicate it here.

## Candidate generation (no symbol given)
`references/screen-intake.md` — Tapetide `screen_stocks` trigger + alert queries (historically tested), offline fundamental grading, then mandatory weekly verification.

## Cross-skill boundaries
- `tapetide-technical-analysis` → open-ended RSI/MACD/ADX reads. This skill does **not** use those indicators; don't mix them in.
- `quality-business-at-fair-price`, `megatrend-investing` → different entry philosophies. Keep verdicts separate.
- Position sizing questions (8% stop, 10% position cap) belong here even without a chart question.

## Re-running the evidence
`scripts/` holds the backtest (`extract_breakouts.py` → `simulate_stops.py`) and the screen test (`test_screens.py`). Run from a folder with `eod2_data/` and `bt_out/arr/`; full NSE takes ~2 minutes. Re-run before changing any stop or selection threshold.
