# Screen intake — finding candidates without being given a symbol

Use when Rajat asks for a scan, a watchlist refresh, or "any entries" without naming stocks.
Goal: the best few candidates for the fewest Tapetide calls (free tier = **50 calls/day**; a full run below costs ~5–10).

## The funnel

| Step | Tool | Tapetide calls |
|---|---|---|
| 1. Trigger screen (Q1) | Tapetide `screen_stocks` | 1 |
| 2. Alert screen (Q2), weekend runs only | Tapetide `screen_stocks` | 1 |
| 3. Fundamental grade from the screen's own columns | none (offline) | 0 |
| 4. Rank: trigger state → fundamental grade → volume/extension | none | 0 |
| 5. Weekly bars for the top ≤8 | `eod2_data` CSVs (completed weeks) | 0 |
| 6. Live price for the shortlist | `get_batch_quotes` (≤20 symbols) | 1 |
| 7. The "why" for the final 1–3 | `web_search` first; `get_company_profile` only for other-income / cash-flow checks | 0–3 |

If `eod2_data` is unavailable, step 5 falls back to `get_price_history(weekly, days=450)` at 1 call per stock.

## Q1 — TRIGGER (possible ENTRY this week)

Tapetide `screen_stocks`, `sort: "Return on capital employed"`, `order: "desc"`, `limit: 50`:

```
Down from 52w high < 4 AND
Current price > DMA 50 AND
DMA 50 > DMA 200 AND
Market Capitalization > 1000 AND
Volume 1year average > 100000 AND
Volume 1week average > Volume 1year average AND
Debt to equity < 3 AND
Pledged percentage < 10
```

**Syntax limit (found 19 Oct 2026):** Tapetide's grammar is `{ratio} {op} {number | ratio}` only. A multiplier on either side (`DMA 50 * 1.15`, `Volume 1year average * 1.8`, `1.8 * Volume 1year average`) is rejected with `Unexpected "*"`. Cross-field comparisons with no multiplier still work. So the two caps that used a multiplier are now applied in Step 5 from the weekly bars, not in the screen:
- **Extension:** keep only names with last close ≤ 1.15 × the 13-week SMA (and note the 50-DMA in the screen is an *exponential* average per Tapetide's catalog, so it will differ from a simple 50-day average).
- **Volume band:** keep only breakout-week volume of 2x–5x the 20-week median (per-session normalized); the 1.8x/5x screen cut is replaced by the plain `1 week > 1 year` test above.

Expect about 2–3x more raw hits than the old Q1 (16 on 19 Oct 2026, a Monday). Most are dropped in Step 5 for extension or volume, so the final list is unchanged in kind.

## Q2 — ALERT (coiling under the high; finds the setup a week early)

```
Down from 52w high > 1.5 AND
Down from 52w high < 5 AND
Volume 1week average < Volume 1year average AND
Current price > DMA 50 AND
DMA 50 > DMA 200 AND
Market Capitalization > 1000 AND
Volume 1year average > 100000 AND
Debt to equity < 3 AND
Pledged percentage < 10
```

(The old `Current price < DMA 50 * 1.10` line is removed for the same syntax reason; apply "close ≤ 1.10 × 13w SMA" in Step 5.) Returned 19 hits on 19 Oct 2026, and the output includes `avg_vol_1wk` and `avg_vol_1yr` columns.

**Screener.in:** the queries above run unchanged in "Create new screen → query" (Screener itself accepts the multiplier forms, so on Screener.in you may add `Current price < DMA 50 * 1.15` and `Volume 1week average > Volume 1year average * 1.8` back) (Tapetide's catalog uses Screener's ratio names). Add columns ROCE, Qtr Profit Var, Qtr Sales Var, OPM, CFO/PAT if available, so step 3 needs nothing else.

### Test status (be explicit about this when sharing the queries)
- **Live-tested on Tapetide, 19 Oct 2026:** the revised Q1 (16 hits) and Q2 (19 hits) above run clean. The multiplier forms from the earlier version fail on Tapetide with `Unexpected "*"`; the 1 Oct 2026 test below predates that change.
- **Live-tested on Tapetide, 1 Oct 2026:** every ratio name above, the `X > Y * 1.8` cross-field syntax, and the version of Q1 *without* the two new lines (`< DMA 50 * 1.15`, `< Volume 1year average * 5`) → 18 hits. The two new lines use the same verified syntax but hadn't been run live when written; on their first live run, confirm the count drops to roughly a third.
- **Historical test (2012–2026, whole NSE, Friday-close screens, next-open entry, 8% stop, 13-week horizon):**

| Screen | Hits/week | Win % | Avg return |
|---|---|---|---|
| Baseline: any uptrend stock (close > 50 > 200 DMA) | 272 | 34.7 | 2.54% |
| Old trigger (down < 4%, 1w vol > 1.8x 1y) | 17.6 | 33.6 | 2.83% |
| **Q1** (adds vol < 5x, close < 1.15 × DMA 50, ATR < 5%) | **6.1** | **45.3** | 3.20% |
| Old alert (down 1.5–8%, vol < 1y) | 55 | 39.9 | 2.73% |
| **Q2** tight (down 1.5–5%, close < 1.10 × DMA 50, ATR < 4%) | **19.8** | 44.7 | 2.15% |

Read honestly: Q1 cuts the list to a third (the API saving) and raises the hit rate, with a small return gain — post-2019 better (3.82% vs 3.18%), 2012–18 slightly worse (1.56% vs 1.91%). It is a better filter, not a magic one. Q2's forward returns aren't higher on their own — its job is timing (alerts before the breakout), not selection.

The ATR condition can't be expressed in `screen_stocks`; apply it in step 5 (daily ATR ≤ 5%, or weekly ATR ÷ 2.27).

## Step 3 — fundamental grade from the screen columns (no extra calls)

| Grade | Rule (columns: ROCE, Qtr profit var, Qtr sales var) |
|---|---|
| A | ROCE ≥ 20, profit growth ≥ 20%, sales growth ≥ 15% |
| B | ROCE ≥ 12 and both growths > 0 |
| C | One growth negative, or ROCE < 12 |
| Drop | Quarterly net profit < 0, or profit growth < −30% (list by symbol only) |

The fundamental grade decides **size and tie-breaks, never whether a triggering stock gets looked at** (SEDEMAC ranked 7th on fundamentals alone on 1 Oct 2026 but was the cleanest trigger).

## Step 4 — ranking

1. **Trigger state**: Q1 hits before Q2 hits (a trigger's action window is one week).
2. **Fundamental grade** A → B → C.
3. Within a grade: volume multiple nearest 2–3x, then smallest distance above the 13w SMA (both measured on weekly bars).

Deep-verify at most 8; list the rest by symbol.

## Step 5 — mandatory weekly verification

The screen has no weekly bars, so its hits are candidates only. For each shortlisted name compute: the 52-week-high pivot, 13w SMA and slope, per-session-normalized volume vs the 20-week median, close location, base depth, daily ATR %. Only then assign a verdict. Discard anything more than ~10% below its 52w high (a pullback, not a breakout).

## Cadence and timing
- **Last session of the week, after 15:30** (Friday, or Thursday before a Friday holiday): Q1 + Q2, verdicts, next-week action plans. The only run where triggers resolve.
- **Mon–Thu:** Q2 only, for names newly within ~5% of the high. No verdicts.
- Intraday runs read a partial week; `Volume 1week average` is a rolling 7-day mean, not the calendar week.
