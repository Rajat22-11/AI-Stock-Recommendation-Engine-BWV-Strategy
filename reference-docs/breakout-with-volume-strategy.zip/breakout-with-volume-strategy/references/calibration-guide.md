# Calibration guide

Starting bands, not hard rules. Always print the measured number beside the band.

## 1. Prior correction depth (Stage 1, condition 1)
Fall from the prior ATH/52w high to the base trough.

| Depth | Read |
|---|---|
| 40–60%+ over several months | Textbook Deodhar base (MTAR −60%/18 months, DICABS −57%/4 months) |
| 25–40% | Acceptable (Varun Beverages −38%) — but note it as shallower |
| < 25% | Not a real shake-out base; momentum continuation, mark the setup lower quality |

Duration matters less than depth: 4 months (DICABS) and 18 months (MTAR) both worked.

## 2. Higher low (condition 2)
Use 3-bar weekly pivot lows: a weekly low with higher lows on both sides. The first pivot low **above** the base trough is the higher low. Report both prices and dates. No higher low yet → `WAIT (alert)`, not `ENTRY`.

## 3. Breakout volume (condition 4)
Breakout-week volume ÷ **median** of the prior 20 completed weeks, each normalized per session (a 4-session holiday week ×5/4). Median, not mean — one earlier climax week distorts the mean badly (AEGISLOG Sep 2026: mean 10.7M vs median 5.7M).

| Multiple | Read | Backtest (cap bp/trade) |
|---|---|---|
| < 1.5x | Not a volume breakout — false start risk | — |
| 1.5–2x | Marginal; needs a strong why | — |
| 2–3x | Confirmed — the sweet spot (Deodhar: "two, three times average") | 50 |
| 3–5x | Strong | 39 |
| 5–10x | Edge shrinks — often a news pop | 30 |
| > 10x | Weakest (climax / circuit spike: KMCSHIL 30x, FINCABLES 17x) — lower conviction | 22 |

## 4. Stops (Stage 1, step 4) — revised 1 Oct 2026
**Stop = fill × 0.92**, hard GTT. Evidence: `backtest-stops.md` (10,866 trades).

| Case | Stop |
|---|---|
| Any Setup A or B entry | Fill × 0.92 |
| Fill unknown | "8% below your fill — at ₹X that is ₹Y" |
| Price closes back below the pivot | Warning only (breakout failing); stop unchanged |
| Add (Stage 3) | Add fill × 0.92 on the added shares (not separately tested) |

Superseded rule — pivot − 1%, capped at 8%: worst-performing rule tested (77% stopped, 26 bp vs 37 bp per trade). It put the stop inside one day's range whenever the fill was near the pivot: JSWINFRA (fill ₹360.45, stop ₹353) and SEDEMAC (fill ₹3,449, stop ₹3,335, ATR ₹169) both stopped out on day one.

Worked example (ACMESOLAR, Sep 2026, re-done): fill ₹458.1 → stop ₹421.45 (old rule gave ₹426).

## 5. Trim triggers (Stage 2)
- **+25% from the buy point** → trim 25–33%. Mechanical.
- **Stock-specific overextension**: measure the last 2–3 local peaks, each as % above the 13-week SMA at that peak, and note how far it ran before reverting. Current distance ≥ that stock's own typical peak → trim regardless of gain%. Ranges genuinely vary (15% on some names, 30%+ on others) — never apply one fixed number.

## 6. High tight flag (Stage 3)
| Feature | Healthy flag | Early breakdown |
|---|---|---|
| Shape | Tight horizontal range or shallow descending ladder near highs | Wide, accelerating down-bars |
| Depth | Shallow relative to the preceding run | Deep retrace, undercuts the SMA |
| Volume | **Dries up**, below the 20w median | Rising on down weeks |
| SMA | Rising, catching up to price | Flattening/rolling over |

Add trigger = weekly close above the flag high on volume clearly above the flag's average (≥1.5x the dried-up level, and at/above the 20w median). Never add inside the flag.

## 7. Exit-sequence signals (Stage 4)
| Signal | Test |
|---|---|
| 1 Euphoria/exhaustion | Already extended vs the stock's own history (§5) **and** expanding further on ≥2x median volume instead of consolidating |
| 2 Failure bar | Inside bar, inverted hammer or doji on ≥1.5x median volume after a parabolic push; close in the lower half of the range strengthens it |
| 3 Distribution chop | 3+ of the last ~6 weeks wide-range (range ≥1.5x the recent average) with elevated volume, but net price change roughly flat |
| 4 Capitulation | Weekly close below the most recent higher low, on ≥1.5x median volume, with follow-through rather than an immediate bounce |

A heavy-volume down week that closes in the **upper third** of its range is absorption, not distribution (WELCORP and FINCABLES, w/o 14 Sep 2026, both ~85% of range).

## 8. Why-quality grading (Stage 1, step 2)
| Grade | Driver | Effect |
|---|---|---|
| A | Earnings beat-and-raise, order wins with numbers, margin expansion, capacity | Full `ENTRY` |
| B | Sector tailwind / re-rating backed by recent reported numbers | `ENTRY` |
| C | Fund-raise, preferential warrants, marquee-investor entry, index inclusion, roadshow/investor-meet pops | `ENTRY (reduced)` |
| D | Nothing discoverable, or tip chatter | `ENTRY (reduced)` or `NO-GO` |

Downgrade one grade if other income is a large share of profit, if growth is off a one-off/low base, or if operating cash flow has collapsed. Note warrant/QIP conversion prices (future supply) and ASM/GSM placement. Extreme PE is noted, never a gate.

## 9. Base quality (ranking `WAIT (alert)` setups)
Range over the last ~8 completed weeks, with the volume trend inside it.

| Range | Volume | Read |
|---|---|---|
| ≤12% | drying up | Highest-quality alert |
| 12–20% | ≤1x median | Normal base |
| 20–30% | any | Loose — demand ≥3x volume on the break |
| >30% | any | Not a base; use Stage 3/4 logic instead |

## 10. Volatility filter — daily ATR(14) % of price
Daily ATR from daily bars; with weekly bars only, weekly ATR(14) ÷ 2.27.

| Daily ATR % | Backtest (cap bp/trade, 8% stop) | Action |
|---|---|---|
| ≤ 3% | 56 | Normal |
| 3–4% | 52 | Normal |
| 4–5% | 35 | Normal, note it (SEDEMAC 4.9%) |
| 5–7% | 21 | Half size, one notch lower conviction |
| > 7% | −14 | `NO-GO` |

## 11. Market breadth
Not a gate. Breakouts during weak breadth (<50% of NSE above 200 DMA) returned ~47 bp vs ~35 bp in strong breadth. Report the tape as context only.
