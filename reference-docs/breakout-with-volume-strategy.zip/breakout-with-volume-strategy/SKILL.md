---
name: "breakout-with-volume-strategy"
description: "Use for Rajat's stage-based breakout-on-volume trading process (the \"Ashish Deodhar\" framework) — entering a new breakout candidate, trimming/booking profit, adding on a flag breakout or SMA refill, or exiting through the 4-signal distribution sequence. Trigger whenever Rajat mentions a stock making a new 52-week high, \"upper circuit\", a volume spike, a breakout, a pullback/flag, heavy selling/distribution, or asks \"should I add/trim/exit X\", \"check X for entry\" — even without naming the framework. Also trigger for stop-loss placement (8% below fill) and 10%-position sizing questions tied to this process. DISTINCT from tapetide-technical-analysis and fundamental-analysis (those give open-ended ratings); this gives a strict verdict (ENTRY/TRIM/ADD/EXIT/HOLD/WAIT/NO-GO) inside Deodhar's loop, on WEEKLY candles, always computed fresh, and ALWAYS returns concrete prices to act on (entry zone, stop, trim level). NEVER assume/infer a buy price — if needed and not stated this conversation, ask first."
---

# Breakout-with-Volume Strategy (Deodhar Framework)

Rajat's breakout process, run on **weekly** candles, NSE stocks, via Tapetide MCP.
Source: Ashish Deodhar's four articles (the loop, the buy, trim & add, the exit).
Calibration numbers: `references/calibration-guide.md`. Tool recipes: `references/tooling.md`. Scans: `references/screen-intake.md`. Past calls: `references/case-log.md`. Stop/selection evidence: `references/backtest-stops.md` (re-runnable: `scripts/`).

## Core principle

This is a **stage-gate checklist**, not a technical opinion. Identify which stage Rajat is in, run only that stage, on fresh weekly data, and **always end with prices he can act on** — never a verdict alone.

## How to apply it: soft on watching, strict on buying, fixed on risk

Deodhar runs this with judgment, not as a rigid gate. His own weekly watchlist includes names that miss a threshold (Vidhi at RS 79 against his 80 bar; Nykaa at RS 64 kept as a clean flag). Three tiers:

| Tier | What it covers | How strict |
|---|---|---|
| **Watchlist** | Which stocks deserve attention | **Soft.** Score the selection signals; a near-miss is noted, not disqualified |
| **Trigger** | When to actually buy or add | **Strict.** A weekly close above the pivot/range on real volume. No trigger, no buy |
| **Risk** | 8% stop, 10% position cap (≤0.8% risk), 25% trim, exit sequence | **Fixed.** Never bent for conviction |

Report conviction as High / Medium / Low from how many selection signals line up, and let it scale position size. Don't refuse a setup over one borderline number; say which number is borderline.

## Non-negotiable rules

1. **Never assume, infer, or carry forward a buy/entry price.** If a stage needs it and he hasn't said it in *this* conversation, ask: "What was your entry price and date for [SYMBOL]?"
2. **Never assume total capital.** Ask before sizing.
3. **Always weekly bars.** 52-week high, 13-week SMA, volume comparisons, flags, higher lows — all weekly.
4. **Every output carries actionable numbers**: entry zone, **stop-loss price**, trim price, add trigger price, exit trigger price — whichever the stage needs. A verdict with no price is an incomplete answer.
5. **The initial stop is 8% below the fill price — not the pivot, not the SMA.** See Stage 1 Step 4 and `references/backtest-stops.md` (10,866 NSE breakouts, 2012–2026). A tight pivot-based stop was the single worst rule tested. The 13-week SMA is a trend reference and trim gauge only.
6. **Judgment calls show their numbers.** State every multiple and % you measured.
7. **Probability, not prediction.** Four conditions can all line up and the trade still fails (Varun Beverages). Never present a verdict as a forecast.
8. **One stock, one verdict tag**: `ENTRY`, `ENTRY (reduced)`, `WAIT`, `WAIT (alert)`, `NO-GO`, `TRIM`, `ADD`, `HOLD`, `REDUCE`, `EXIT`.

## Data hygiene (before any stage)

1. **Partial week.** If the week's last session hasn't closed, label the bar `PARTIAL (n sessions)`; compare volume per session, and judge triggers only on the last *completed* weekly bar.
2. **Holiday-short completed weeks.** Scale volume ×5/sessions before comparing.
3. **Corporate actions.** Compare `close` vs `raw_close`; a demerger/split can fake or hide a 52-week high.
4. **Surveillance.** Check for ASM/GSM, circuit-band or T2T changes and flag them.
5. **Stop executability (microcaps and circuit stocks).** Report the median weekly turnover and whether the stock has been hitting circuit bands. In a 5%/10% circuit scrip a stop-loss cannot fill once the band locks — the position gaps past it. Say this plainly whenever it applies: the stop is then a decision level, not a guaranteed exit, so size smaller rather than relying on the stop.

## Determining the stage

| Signal | Stage |
|---|---|
| New candidate, no position, "is this breaking out", fresh 52w high / volume spike | **Stage 1 — Buy** |
| Position up, "should I book", or price stretched far from the 13w SMA | **Stage 2 — Trim** |
| Position held, price consolidating near highs or just popped out of a range | **Stage 3 — Add** |
| Position held, parabolic/exhaustion/heavy selling/"is this the top" | **Stage 4 — Exit sequence** |
| Unclear | Ask, before running numbers that need an entry price |

---

## Selection signals (score these for every candidate)

Used for the watchlist and to set conviction. From Deodhar's weekend routine:
1. **Relative Strength ≥80**, ideally 90s (percentile of the stock's return vs the market). See `tooling.md` for how to approximate it.
2. **Stacked weekly SMAs**: 13 > 26 > 39 > 52.
3. **Higher-high / higher-low structure.**
4. **Accelerating EPS and revenue growth YoY** — each recent quarter faster than the last, not just positive.
5. **Tight range near the prior 52-week high**, with support at the rising 13-week SMA.
6. Promoter/institutional holding rising (a plus, not required).

Valuation is noted, never a gate (Cupid is on his list at PE 287).

**What the backtest says about selection** (`references/backtest-stops.md`, univariate, 8% stop):
- **Breakout volume 2–3x is the sweet spot** (~50 bp/trade). 3–5x ~39 bp, 5–10x ~30 bp, **>10x ~22 bp** — huge news/circuit spikes (KMCSHIL 30x, MUKANDLTD 8x) are weaker, not stronger. Lower conviction above ~5x.
- **Tight to the 13w SMA at the signal** (≤10% above) is best (~54 bp); 10–30% above is weaker.
- **Deep bases (≥35% correction) beat 20–35% ones** (~46 bp vs ~20 bp); shallow <20% (Setup B) sits between (~39 bp).
- **Market regime is not a gate.** Breakouts that fired while <50% of NSE stocks were above their 200 DMA did *better* (~47 bp) than in strong breadth (~35 bp). Mention a weak tape as context; never block or shrink a trigger for it.

## Two entry setups

**Setup A — Base breakout** (a stock emerging from a deep correction). Stage 1 below.
**Setup B — Continuation / flag breakout** (a stock already in an uptrend). The same logic as Stage 3's add, applied to a *new* position: a tight range near highs, support at the rising 13w SMA, volume drying up, stacked SMAs, strong RS. Trigger = weekly close above the range high on above-average volume. Stop = 8% below the fill (same rule as Setup A). Examples from his list: Cupid, Nykaa, Eternal.

A stock with no deep correction is **not** disqualified — it's a Setup B candidate. Never tell Rajat a strong uptrending stock "fails condition 1" without checking it as Setup B.

## Stage 1 — The Buy (Setup A): four conditions

Deodhar: "Not three. Not most of them. All four." Conditions 3 (breakout close) and 4 (volume) are the **strict trigger**. Conditions 1–2 describe the base; a shallower correction or a messier higher low lowers conviction rather than voiding the setup — and if there was no correction at all, evaluate as Setup B. Report each as ✅/🟡/❌ with the measured number.

**Condition 1 — a deep prior correction.** From the prior all-time or 52-week high, the stock must have fallen hard — typically 40–60%+, over months, not a 10–15% wobble. Why: a deep, drawn-out fall exhausts the weak holders, so overhead supply is thin. Report: peak price/date, trough price/date, % fall, months taken.
*If the correction is shallow (<25%), this is a momentum continuation, not a Deodhar base — say so and mark the setup lower quality.*

**Condition 2 — the first higher low.** After the trough, a swing low that sits **above** the base trough (use 3-bar weekly pivot lows). Report both lows and the dates. This is the first objective evidence sellers can't press it lower.

**Condition 3 — breakout above the prior 52-week-high pivot.** A weekly **close** above the pivot (the highest weekly high of the prior 52 weeks). Name the **pivot price explicitly** — it defines the stop. Note if the prior ATH sits just above; clearing both in one move is stronger.

**Condition 4 — volume confirmation.** Breakout-week volume ≥2x the **median** of the prior 20 completed weeks (per-session normalized). Marginal upticks don't count. State the multiple; above ~5x, note that the backtest edge shrinks.

**Step 2 — the fundamental "why".** Dig for the driver: earnings beat-and-raise, order wins, margin expansion, new product/market, management change, sector tailwind. Grade it (`calibration-guide.md` → Why-quality). Price leads, fundamentals confirm: a credible why earns a **full** position, a weak/absent why earns a **much smaller one or none**.

**Step 3 — verdict.**
- All 4 + credible why → `ENTRY`
- All 4 + weak/no why → `ENTRY (reduced)`
- Conditions 1–2 present, 3–4 not yet → `WAIT (alert)` with the exact pivot price to alert on and the weekly volume needed
- Breakout on light volume → `WAIT` (false-start risk), say what volume would qualify
- No real base, or a clearly bad fundamental backdrop → `NO-GO`
- **A failed breakout does not disqualify the stock.** If a prior attempt stopped out, a *second* higher low + a *second* breakout above the same pivot is a fresh, fully valid `ENTRY` (Acutaas). Say so instead of blacklisting the name.
- **Re-entry is a new trade.** After a stop-out (or a correct Stage 4 exit), the stock stays on the watchlist. When it builds a new base and breaks out on volume again, treat it with no memory of the old position: new pivot, new 8% stop from the new fill, fresh sizing — never compare to the old buy or exit price. A missed entry likewise goes on the watchlist, not the chase list; wait for the next base. Source: Deodhar's Venus Remedies note (exited correctly, skipped the re-breakout at ₹854, stock went to ₹1,633), plus Styrenix, TD Power, Quality Power re-entries.

**Step 4 — the stop (MANDATORY, always a rupee price).**
> **Stop = fill price × 0.92 (8% below the fill), placed as a hard GTT.** The pivot is a warning line, not the stop.

Why (full numbers in `references/backtest-stops.md`; 10,866 NSE 52-week-high volume breakouts, 2012–2026, 18 stop rules tested on identical trades):
- The old rule (pivot − 1%, capped at 8%) was the **worst** non-trivial rule: 77% stopped out, 37% of those stops went on to rally 15%+ (whipsaws), and capital return per trade was ~26 bp vs ~37 bp for a flat 8%. When the fill is within 3% of the pivot — the normal, "good" entry — the gap was 13 bp vs 38 bp: the stop sits inside one day's noise. This is exactly what stopped out JSWINFRA (₹353, fill ₹360.45) and SEDEMAC (₹3,335, fill ₹3,449) on day one.
- ATR-based stops (pivot − 1.5×ATR, capped 8%) and the breakout-week low tied with the flat 8% (within ~1 bp). ATR adds nothing to stop *placement*; use it as the volatility filter in Step 4b instead.
- Close-based stops (exit on a daily close below the pivot) were **worse** than intraday stops — fewer intraday whipsaws but more close-basis whipsaws and later, worse fills. Don't use them.
- Wider stops (10–12%) scored noticeably higher in-sample (~45 bp vs ~37 bp), but the dataset has survivorship bias (delisted stocks missing) that flatters wide stops, and 8% is Deodhar's ceiling. Keep 8%.

State it as "set your GTT stop at ₹X (8% below your fill)". If the fill is unknown yet, give it as "8% below whatever you fill at; at ₹Y that is ₹Z". If price closes back below the pivot, say so as a **warning** (the breakout is failing) — but the exit is still the 8% stop or the Stage 4 sequence.

**Step 4b — volatility check (daily ATR(14) as % of price).** Compute daily ATR from daily bars, or weekly ATR(14) ÷ 2.27 if only weekly bars are at hand (measured ratio across NSE, IQR 2.1–2.5).

| Daily ATR % | Backtest (8% stop) | Effect |
|---|---|---|
| ≤ 4% | ~52–56 bp/trade, win 34–44% | Normal |
| 4–5% | ~35 bp | Normal, note it |
| 5–7% | ~21 bp, win 20% | One notch lower conviction; **half size** |
| > 7% | negative | `NO-GO` — an 8% stop is inside 1–2 days' noise |

**Step 5 — sizing.** With an 8% stop, the 10% position cap always binds before the 1% risk rule (10% × 8% = 0.8% of capital at risk). So: **position = 10% of capital** (half that for C/D why grades, ATR 5–7%, or circuit/illiquid stocks). Show the rupee risk. Ask for capital if unknown.

**Step 6 — the action plan.** Entry zone (breakout close to +5%), the stop price, the **+25% trim price**, and "this signal is live for the coming week; if unexecuted it reverts to `WAIT (alert)` at the new pivot."

---

## Stage 2 — Trim (two independent triggers)

Requires entry price — ask if unknown.

**Trigger A — the 25% rule.** Price +25% from the buy point → trim **a quarter to a third**. Mechanical, no exceptions. State the exact rupee level. Explain, when it looks wrong, that it protects against the third pattern: the stock that runs 25% and gives it all back through the pivot.

**Trigger B — overextension from the 13-week SMA (stock-specific).** The SMA acts like a magnet; the further price stretches, the harder the snap-back. **Do not use a fixed %.** Measure the last 2–3 times this stock got extended and note how far it ran before reverting — that is this stock's own threshold (some revert at 15%, others stretch 30%+). Report the historical values and the current distance. If current ≥ its own typical threshold → `TRIM`, even if the gain is under 25%.

Also: if the stock is making a parabolic push **further** from the SMA on heavy volume instead of resting, that is Stage 4 Signal 1 — go there.

Output: current gain %, the +25% price, this stock's historical extension thresholds, current extension, the trim quantity (25–33%), and a note that the rest rides.

---

## Stage 3 — Add (flag breakout, or a 13-week SMA refill)

**What to look for — the high tight flag.** After a run, price pauses near the highs — either a horizontal range or a shallow descending ladder — while the rising 13-week SMA catches up. The tell is **volume drying up** during the pause (below the 20-week median). Shape varies; behaviour doesn't.

**When to add — the precise rule.** Add **only after** (a) the SMA has caught up and offered visible support, and (b) price **breaks out of the top of the flag on clearly above-average volume**.
**Never add inside the flag, or while price is still pulling back** — a flag can crack down through the SMA just as easily as it can bounce. Wait for evidence, not a guess.

**Second trigger — the 13-week SMA refill.** Add on a **weekly close back above a rising 13-week SMA** after that week's low came within ~2% of the SMA (SMA higher than 4 weeks ago). Volume on the pullback is not a condition — it made no difference in testing. Act only on the weekly close, never intra-week (Deodhar added to Acutaas at the SMA mid-week on 31 Jul 2026 and the week closed below it).
Use it to **buy back shares sold at the Stage 2 trim**, not to exceed the cap: with an 8% stop the first entry already uses the full 10%, and the first entry earns about twice what an add does, so never start small to leave room for adds.

Backtest (Oct 2026 re-run of the stop backtest: 10,517 NSE breakouts 2012–2026, each add as its own trade with an 8% stop, exiting with the parent): SMA refill +3.7% avg, PF 1.60, steady across 2012–18 / 2019–26 (+3.4% / +3.8%); flag-breakout add +3.4%, PF 1.54, but fading (+6.9% → +2.2%); initial breakout entry +7.5%, PF 2.14.

Output: the flag's high and low (the add trigger is a weekly close above the flag high), the volume needed, the SMA level, whether volume has dried up, and — if the add triggers — the stop on the added shares (8% below the add fill), the incremental shares, and the check that total position stays ≤10% of capital.

Verdict: `ADD` on a confirmed flag breakout or an SMA refill (say which, and the shares to restore); `HOLD` if still inside the flag (give the trigger price); go to Stage 4 if the flag is cracking down on rising volume.

---

## Stage 4 — Exit: a four-signal sequence, each one sells more

The exit is **never** one decision. Identify which of the four signals has printed and reduce accordingly.

| # | Signal | What it looks like | Action |
|---|---|---|---|
| 1 | **Euphoria / exhaustion bar** | Already extended from the 13w SMA, and instead of resting price expands *further* on heavy volume | Start booking **aggressively**. Each further parabolic week = another reduction |
| 2 | **Failure bar** | Inside bar, inverted hammer or doji on heavy volume after the parabolic push — buyers pushed, price went nowhere | Reduce again. Exhaustion, not yet distribution |
| 3 | **Distribution chop** | Wide-range, directionless weeks on elevated volume; volatility up, price net flat; a higher low may form and hold for a while | Keep reducing. **Not** the final exit — the higher low may hold |
| 4 | **Capitulation** | Decisive break **below the most recent higher low**, on heavy sell volume that continues rather than fades | **Sell the remainder completely** |

- The final trigger is the **break of the higher low**, not a 13-week SMA cross. Name that higher low as a rupee price in every Stage 4 output — it's the line that ends the trade.
- Evidence: a weekly close below the most recent 3-bar pivot low **on ≥1.5x median volume** beat a weekly-close-below-13w-SMA exit by ~42 bp/trade on capital (t = 10) and beat the same break without the volume condition by ~29 bp. Waiting an extra week for "confirmation" made it worse (−10 bp, t = −3.6) — act on the qualifying close. (Oct 2026 backtest, 10,517 NSE breakouts.)
- By design, very little should remain by Signal 4 (often <20–25% of the original position) because Signals 1–3 already cut it.
- Taken at face value: no fundamental explanation needed. The tape leads the news.
- If only Signal 1 or 2 has printed, verdict is `REDUCE`, not `EXIT`; say which signal, and what Signal 4's price is.

**Business kill switch — exit at once, whatever the chart says**, when any of these appears (check news/filings on every review):
- Promoters selling in the open market while talking the business up (Privi, May 2026).
- Auditor's qualified opinion, or a sudden working-capital/cash-flow deterioration that breaks the thesis (Diamond Power, Aug 2026).
- A policy or regulatory change that hits the business directly, and the stock opens below its breakout pivot on heavy volume (Sky Gold, gold import duty, May 2026).
Verdict `EXIT`; name the event and the filing/news source. These are Deodhar's own documented exits; not backtestable on price data.

---

## Using the tools

Full recipes in `references/tooling.md`. In brief:
- **Price/volume, zero API cost:** the `eod2_data` GitHub CSVs (whole NSE, split-adjusted, updated weekly) cover every *completed* week — use them first and save Tapetide calls for the live week. Recipe in `tooling.md`.
- **Price/volume via Tapetide:** `get_price_history(symbol, interval="weekly", days=730)` for the base, correction, pivots, SMA, volume; `get_price_history(days=10)` daily to count sessions in a partial week; `get_batch_quotes` / `get_stock_quote` for live price.
- **The why:** Tapetide `get_company_profile`, `get_stock_events(type="news"/"corporate_actions"/"filings")`, `get_earnings_call_summary`, `get_forecasts`, `get_shareholding`, `get_promoter_pledge`; plus `web_search` for the last 2 weeks of news. For a deeper read, hand off to the `fundamental-analysis` / `finology-fundamental-analysis` skill and relay FinStar — don't re-derive it here.
- **Finding candidates with no symbol given:** `references/screen-intake.md` — the tested Tapetide `screen_stocks` queries (Screener.in equivalents included), the ranking order (trigger state first, fundamental score second) and the API budget. Screener hits are candidates, never verdicts.
- **Never** output an HTML/JS artifact — plain markdown tables only.

## Watchlist mode

When Rajat asks for a watchlist, a weekend scan, or "what should I watch", produce Deodhar-style entries rather than verdicts. For each stock: setup type (A or B), the selection-signal scorecard with numbers (RS, SMA stack, EPS/revenue trend, range width, distance to pivot), **the exact trigger price and the volume that would confirm it**, the stop that trigger would imply, and what would invalidate the idea. Say plainly that a watchlist name may never trigger.

## Output format

Numbers-heavy, tabular, plain markdown. Every stage shows: symbol, live price, last completed weekly close, 13w SMA + slope + distance, data-hygiene flags, the stage's measured numbers, the verdict tag, one line of plain-English reasoning, and **the action table** (entry zone / stop / trim / add trigger / exit trigger, whichever apply) with real prices. Ask for entry price or capital when missing rather than guessing.