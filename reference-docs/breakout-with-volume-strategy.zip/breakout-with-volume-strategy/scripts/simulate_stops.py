import pickle, numpy as np, pandas as pd
S = pickle.load(open("./bt_out/signals.pkl", "rb"))
sig = S["signals"]
bu, bn = S["bu"], S["bn"]
COST = 0.0025
VARIANTS = ["S1_pivot-1%", "S2_pivot-1ATR", "S3_pivot-1.5ATR", "S4_entry-2ATR", "S5_weekLow",
            "S6_fixed8%", "S7_dailyClose<pivot", "S8_weeklyClose<pivot", "S9_dClose+pivot-1ATR"]

cache = {}
def arr(sym):
    if sym not in cache:
        if len(cache) > 300: cache.clear()
        cache[sym] = pickle.load(open(f"./bt_out/arr/{sym}.pkl", "rb"))
    return cache[sym]

rows = []
for s in sig:
    A = arr(s["sym"]); o, h, l, c, dates = A["o"], A["h"], A["l"], A["c"], A["dates"]
    k = s["k"]; e = k + 1; entry = o[e]; piv = s["pivot"]; atr = s["atr"]
    if entry <= piv * 0.99:  # gapped back below pivot before we could buy
        continue
    cap = entry * 0.92
    # common trend exit: first weekly close < 13w SMA after entry -> exit next open; else 52w time stop
    wend, wc, sma, didx = A["wend"], A["wc"], A["sma13"], A["didx"]
    tw = np.searchsorted(didx, e)  # week containing entry day
    exit_i, exit_px = None, None
    for w in range(tw, min(tw + 52, len(wc))):
        if wc[w] < sma[w] and didx[w] + 1 < len(o):
            exit_i, exit_px = didx[w] + 1, o[didx[w] + 1]; break
    if exit_i is None:
        last = min(didx[min(tw + 51, len(wc) - 1)], len(c) - 1)
        exit_i, exit_px = last, c[last]
    # week-end daily indices after entry (for weekly-close rule)
    wk_end_set = set(didx[tw:tw + 53].tolist())
    d = dates[k]; br = bu.get(d, 0) / bn[d] * 100 if bn.get(d) else np.nan
    base = dict(sym=s["sym"], date=pd.Timestamp(s["wk"]), entry=entry, atrp=atr / entry, depth=s["depth"],
                volx=s["volx"], ext=s["ext13"], breadth=br, gap=entry / piv - 1)
    for vname in VARIANTS:
        hard, close_lvl, weekly = None, None, False
        if vname == "S1_pivot-1%": hard = piv * 0.99
        elif vname == "S2_pivot-1ATR": hard = piv - atr
        elif vname == "S3_pivot-1.5ATR": hard = piv - 1.5 * atr
        elif vname == "S4_entry-2ATR": hard = entry - 2 * atr
        elif vname == "S5_weekLow": hard = s["wlow"] * 0.995
        elif vname == "S6_fixed8%": hard = cap
        elif vname == "S7_dailyClose<pivot": hard, close_lvl = cap, piv
        elif vname == "S8_weeklyClose<pivot": hard, close_lvl, weekly = cap, piv, True
        elif vname == "S9_dClose+pivot-1ATR": hard, close_lvl = piv - atr, piv
        hard = max(hard, cap)
        if hard >= entry: hard = cap
        risk = 1 - hard / entry
        xi, xp, how = exit_i, exit_px, "trend"
        for i in range(e, exit_i + 1):
            if l[i] <= hard:
                xi, xp, how = i, (min(o[i], hard) if i > e else hard), "stop"; break
            if close_lvl is not None and c[i] < close_lvl and (not weekly or i in wk_end_set) and i + 1 < len(o):
                xi, xp, how = i + 1, o[i + 1], "stop"; break
        ret = xp / entry - 1 - COST
        whip = np.nan
        if how == "stop":
            fut = c[xi:xi + 60]
            whip = float(len(fut) > 0 and fut.max() >= entry * 1.15)
        # 13-week horizon return with the same stop (no trend exit) for a clean comparison
        hz = min(e + 65, len(c) - 1); r13 = c[hz] / entry - 1 - COST
        for i in range(e, hz + 1):
            if l[i] <= hard:
                r13 = (min(o[i], hard) if i > e else hard) / entry - 1 - COST; break
            if close_lvl is not None and c[i] < close_lvl and (not weekly or i in wk_end_set) and i + 1 < len(o):
                r13 = o[i + 1] / entry - 1 - COST; break
        w = min(0.01 / risk, 0.10)
        rows.append({**base, "v": vname, "risk": risk, "ret": ret, "R": ret / risk, "stopped": how == "stop",
                     "whip": whip, "cap": w * ret, "r13": r13, "cap13": w * r13, "days": xi - e})
R = pd.DataFrame(rows)
R.to_pickle("./bt_out/results.pkl")
print(len(R) // len(VARIANTS), "trades")
