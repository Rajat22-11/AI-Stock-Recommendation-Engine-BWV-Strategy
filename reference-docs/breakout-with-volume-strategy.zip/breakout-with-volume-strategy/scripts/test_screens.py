import glob,os,numpy as np,pandas as pd
files=sorted(glob.glob("./eod2_data/daily/*.csv")); out=[]
def fwd(o,l,c,e,stop_pct=0.08,hz=65):
    entry=o[e]; st=entry*(1-stop_pct); end=min(e+hz,len(c)-1)
    for i in range(e,end+1):
        if l[i]<=st: return (min(o[i],st) if i>e else st)/entry-1-0.0025
    return c[end]/entry-1-0.0025
for f in files:
    s=os.path.basename(f)[:-4]
    if s.endswith("_sme"): continue
    try: df=pd.read_csv(f,usecols=["Date","Open","High","Low","Close","Volume"],parse_dates=["Date"]).dropna().drop_duplicates("Date").sort_values("Date")
    except: continue
    df=df[(df.Close>0)&(df.Low>0)&(df.Date>="2010-06-01")].reset_index(drop=True)
    if len(df)<300: continue
    o,h,l,c,v=(df[k].to_numpy(float) for k in ["Open","High","Low","Close","Volume"])
    S=lambda x,n:pd.Series(x).rolling(n).mean().to_numpy()
    d50,d200,v5,v250=S(c,50),S(c,200),S(v,5),S(v,250)
    hi=pd.Series(h).rolling(250).max().to_numpy()
    pc=np.r_[c[0],c[:-1]]; tr=np.maximum(h-l,np.maximum(abs(h-pc),abs(l-pc))); atr=pd.Series(tr).ewm(alpha=1/14,adjust=False).mean().to_numpy()
    turn=pd.Series(c*v).rolling(20).median().to_numpy()
    dt=df.Date; wkk=dt.dt.isocalendar().week.to_numpy().astype(np.int64); fri=(wkk!=np.r_[wkk[1:],-1])  # last day of each ISO week
    idx=np.where(fri&(dt>="2012-01-01").to_numpy()&~np.isnan(d200)&~np.isnan(v250)&~np.isnan(hi))[0]
    for i in idx:
        if i+1>=len(c) or turn[i]<1e7 or c[i]<30: continue
        if not (c[i]>d50[i]>d200[i]): continue
        down=1-c[i]/hi[i]; vr=v5[i]/v250[i]; ext=c[i]/d50[i]-1; atrp=atr[i]/c[i]
        out.append((s,dt[i],down,vr,ext,atrp,fwd(o,l,c,i+1)))
R=pd.DataFrame(out,columns=["sym","date","down","vr","ext","atrp","r"]); R.to_pickle("./bt_out/scr.pkl"); print(len(R))
