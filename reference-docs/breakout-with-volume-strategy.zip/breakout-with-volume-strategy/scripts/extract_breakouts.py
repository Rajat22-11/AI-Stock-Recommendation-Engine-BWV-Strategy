"""Stop-loss variant backtest on NSE 52-week-high volume breakouts (Deodhar-style).

Signal (weekly, W-FRI): weekly close > pivot (= highest weekly high of prior 52 weeks),
prior week close <= its own pivot (fresh breakout), per-session-normalized weekly volume
>= 2x median of prior 20 weeks, close > 13w SMA, price >= 30, median 20d turnover >= Rs 1 cr.
Entry: next session open. All stops capped at 8% below entry (whichever closer).
Common exit: weekly close below 13w SMA (exit next open) or 52-week time stop.
"""
import os, sys, glob, pickle
import numpy as np, pandas as pd

D = "./eod2_data/daily"
START = pd.Timestamp("2012-01-01")
COST = 0.0025  # round trip
files = sorted(glob.glob(f"{D}/*.csv"))
if len(sys.argv) > 1:
    files = files[: int(sys.argv[1])]

breadth_up = {}
breadth_n = {}
signals = []

def atr14(h, l, c):
    pc = np.r_[c[0], c[:-1]]
    tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    a = np.full_like(tr, np.nan)
    if len(tr) < 15:
        return a
    a[13] = tr[:14].mean()
    for i in range(14, len(tr)):
        a[i] = (a[i - 1] * 13 + tr[i]) / 14
    return a

for fi, f in enumerate(files):
    sym = os.path.basename(f)[:-4]
    if sym.endswith("_sme"):
        continue
    try:
        df = pd.read_csv(f, usecols=["Date", "Open", "High", "Low", "Close", "Volume"], parse_dates=["Date"])
    except Exception:
        continue
    df = df.dropna().sort_values("Date").drop_duplicates("Date")
    df = df[(df.Close > 0) & (df.Low > 0)]
    if len(df) < 400:
        continue
    df = df.reset_index(drop=True)
    o, h, l, c, v = (df[k].to_numpy(float) for k in ["Open", "High", "Low", "Close", "Volume"])
    dates = df.Date.to_numpy()
    # breadth (% above 200 DMA)
    sma200 = pd.Series(c).rolling(200).mean().to_numpy()
    m = ~np.isnan(sma200)
    for d, up in zip(dates[m], (c[m] > sma200[m])):
        breadth_up[d] = breadth_up.get(d, 0) + int(up)
        breadth_n[d] = breadth_n.get(d, 0) + 1
    atr = atr14(h, l, c)
    turn = pd.Series(c * v).rolling(20).median().to_numpy()
    # weekly
    wk = df.set_index("Date").resample("W-FRI").agg(
        Open=("Open", "first"), High=("High", "max"), Low=("Low", "min"),
        Close=("Close", "last"), Volume=("Volume", "sum"), n=("Close", "count")).dropna()
    wk = wk[wk.n > 0]
    if len(wk) < 80:
        continue
    wv = (wk.Volume / wk.n * 5).to_numpy()
    wh, wl, wc = wk.High.to_numpy(), wk.Low.to_numpy(), wk.Close.to_numpy()
    piv = pd.Series(wh).shift(1).rolling(52).max().to_numpy()
    med = pd.Series(wv).shift(1).rolling(20).median().to_numpy()
    sma13 = pd.Series(wc).rolling(13).mean().to_numpy()
    hi104 = pd.Series(wh).shift(1).rolling(104, min_periods=60).max().to_numpy()
    wend = wk.index.to_numpy()
    # last daily index of each week
    didx = np.searchsorted(dates, wend, side="right") - 1
    for t in range(60, len(wk) - 1):
        if wend[t] < np.datetime64(START):
            continue
        if not (wc[t] > piv[t] and wc[t - 1] <= piv[t - 1] and med[t] > 0 and wv[t] >= 2 * med[t]
                and wc[t] > sma13[t] and wc[t] >= 30):
            continue
        k = didx[t]
        if k + 1 >= len(c) or np.isnan(turn[k]) or turn[k] < 1e7 or np.isnan(atr[k]):
            continue
        # base depth: max drawdown from the 104w high to the lowest low since then
        j0 = max(0, t - 104)
        seg_h = wh[j0:t]
        im = int(np.argmax(seg_h))
        depth = 1 - wl[j0 + im:t].min() / seg_h[im] if t - (j0 + im) > 0 else 0.0
        signals.append(dict(sym=sym, wk=wend[t], k=k, pivot=piv[t], atr=atr[k], wlow=wl[t],
                            close=wc[t], volx=wv[t] / med[t], depth=depth,
                            ext13=wc[t] / sma13[t] - 1))
    # store arrays needed for simulation
    pickle.dump(dict(o=o, h=h, l=l, c=c, dates=dates, wend=wend, wc=wc, sma13=sma13, didx=didx),
                open(f"./bt_out/arr/{sym}.pkl", "wb"))
    if fi % 250 == 0:
        print(fi, len(signals), flush=True)

pickle.dump(dict(signals=signals, bu=breadth_up, bn=breadth_n), open("./bt_out/signals.pkl", "wb"))
print("done", len(signals))
